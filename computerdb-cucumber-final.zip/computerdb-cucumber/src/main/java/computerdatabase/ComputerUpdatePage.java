package computerdatabase;

import testframework.WebOperations;

public class ComputerUpdatePage {
	
	private WebOperations _webOp = null;
	
	public ComputerUpdatePage( WebOperations webOp ) {
		_webOp = webOp;
	}
	
	public void updateComputerForm( String name, String introDate, String disDate, String company ) {
		
	}
	
	public void submitComputerForm() {
		
	}
	
	public void updateComputer(  String name, String introDate, String disDate, String company ) {
		
	}
	
	public void cancelUpdate( ) {
		
	}

	public boolean verifyHelpMessage( String helpMessage ) {
		boolean result = false;
		return result;
	}

}
